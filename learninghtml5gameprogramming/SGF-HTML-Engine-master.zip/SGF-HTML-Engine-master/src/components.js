/**
 * == Components API ==
 * "Components" are the Object Oriented classes that are created by your game code,
 * added to your game loop and rendered on the screen.
 **/

//{components/Component.js}
//{components/Container.js}
//{components/DumbContainer.js}
//{components/Label.js}
//{components/Sprite.js}
//{components/Shape.js}
//{components/Rectangle.js}

//components/Circle.js remove for now

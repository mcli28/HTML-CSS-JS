/**
 * == Core API ==
 * The lowest level functions and classes. The `Core API` contains objects
 * automatically generated when the engine and game are loaded.
 **/

//{core/EventEmitter.js}
//{core/Screen.js}
//{core/Input.js}
//{core/Game.js}
